import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:rating_bar/rating_bar.dart';

class CarouselClass extends StatefulWidget {
  @override
  _CarouselClassState createState() => _CarouselClassState();
}

class _CarouselClassState extends State<CarouselClass> {
  List<String> images = [
    
      "assets/images/im1.jpg"
    ,
    
      "assets/images/im2.jpg"
    ,
    
      "assets/images/im3.jpg"
    ,
    
      "assets/images/im4.jpg"
    ,
    
      "assets/images/im5.jpg"
    ,
  ];
  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(
        aspectRatio: 16 / 9,
        autoPlay: true,
        viewportFraction:0.9,
      ),
      items: images.map((i) {
        return Builder(
          builder: (BuildContext context) {
            return Container(
              width: MediaQuery.of(context).size.width,
              margin: EdgeInsets.symmetric(horizontal: 5.0),
              decoration: BoxDecoration(color: Colors.amber),
              child: Image.asset(i,fit:BoxFit.cover,),
            );
          },
        );
      }).toList(),
    );
  }
}
