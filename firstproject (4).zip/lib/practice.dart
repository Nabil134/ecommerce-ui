import 'package:flutter/material.dart';
import 'drawer.dart';
import 'bgimage.dart';
import 'home.dart';

void main() => runApp(MyHomePage());

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final userNameController = TextEditingController();
  final passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login Page'),
        backgroundColor: Colors.purple,
      ), //appbar
      body: Stack(
        fit: StackFit.expand,
        children: [
          Bgimage(),
          Center(
            child: SingleChildScrollView(
              child: Card(
                child: Column(children: [
                  Form(
                      child: Padding(
                    padding: EdgeInsets.all(8),
                    child: Column(children: [
                      TextFormField(
                        decoration: const InputDecoration(
                          icon: const Icon(Icons.person),
                          hintText: 'Enter your name',
                          labelText: 'Name',
                        ),
                      ),
                      SizedBox(height: 40),
                      TextFormField(
                        obscureText: true,
                        decoration: const InputDecoration(
                          icon: const Icon(Icons.security),
                          hintText: 'Enter your Password',
                          labelText: 'Password',
                        ),
                      ),
                      SizedBox(height: 40),
                      RaisedButton(
                        padding: const EdgeInsets.all(20),
                        textColor: Colors.white,
                        color: Colors.orange,
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => History()),
                          );
                        },
                        child: Text('Sign In'),
                      ),
                    ]),
                  )), //form
                ]),
              ), //Card
            ), //SingleChildViewScroll
          ),
        ],
      ), //Stack
      drawer: MyDrawer(),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.edit),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        onPressed: () => {},
      ),
    );
  }
}
