import 'package:flutter/material.dart';
import 'home.dart';
import 'history.dart';
import 'practice.dart';
import 'user.dart';
import 'Calculator.dart';
import 'homepage.dart';
import 'screen1.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, //Removing Debug Banner
      home: Scaffold(
        body: home(),
      ),
    );
  }
}
