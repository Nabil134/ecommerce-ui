import 'package:flutter/material.dart';

class Products extends StatefulWidget {
  @override
  _ProductsState createState() => _ProductsState();
}

class _ProductsState extends State<Products> {
  var product_list = [
    {
      "name": "Iphone Pro",
      "picture": "assets/images/im1.jpg",
      "old_price": 18000,
      "price": 14000,
    },
    {
      "name": "Note Ultra 20",
      "picture": "assets/images/im2.jpg",
      "old_price": 20000,
      "price": 18000,
    },
    {
      "name": "Macbook Pro",
      "picture": "assets/images/im3.jpg",
      "old_price": 30000,
      "price": 28000,
    },
    {
      "name": "Macbook Air",
      "picture": "assets/images/im4.jpg",
      "old_price": 40000,
      "price": 35000,
    },
    {
      "name": "Gaming PC",
      "picture": "assets/images/im5.jpg",
      "old_price": 26000,
      "price": 30000,
    },
    {
      "name": "Backlit Keyboard",
      "picture": "assets/images/im6.jpg",
      "old_price": 10000,
      "price": 8000,
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: product_list.length,
        gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (BuildContext context, int index) {
          return Single_prod(
            prod_name: product_list[index]['name'],
            prod_picture: product_list[index]['picture'],
            prod_old_price: product_list[index]['old_price'],
            prod_price: product_list[index]['price'],
          );
        });
  }
}

class Single_prod extends StatelessWidget {
  final prod_name;
  final prod_picture;
  final prod_old_price;
  final prod_price;

  Single_prod({
    this.prod_name,
    this.prod_picture,
    this.prod_old_price,
    this.prod_price,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: Hero(
        tag: prod_name,
        child: Material(
          child: GridTile(
            footer: Container(
              color: Colors.white70,
              child: new Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      prod_name,
                      style: TextStyle(
                        fontSize: 15.0,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  new Text(
                    "\$${prod_price}",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
            ),
            child: Image.asset(
              prod_picture,
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }
}
