import 'package:flutter/material.dart';

class History extends StatefulWidget {
  @override
  _HistoryState createState() => _HistoryState();
}

class _HistoryState extends State<History> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Ecom App UI',
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        actions: [
          Icon(Icons.notifications)
        ],
      ), //AppBar
      body: ListView(children: [
        ABC1('Iphone 12'),
        ABC2('Note 20 Ultra'),
        ABC3('Macbook Air'),
        ABC4('Macbook Pro'),
        ABC5('Gaming PC'),
        ABC6('Backlit Keyboard'),
      ]), //ListView
    ); //Scaffold
  }
}

Widget ABC1(String name) {
  return (Container(
      margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      color: Colors.grey.shade200,
      height: 100,
      child: Row(children: [
        Container(
          height: 95,
          width: 95,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('assets/images/im1.jpg'),
              fit: BoxFit.cover,
            ), //DecorationImage
          ), //BoxDecoration
        ),
        Column(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Text('$name'),
          Row(
            children: [
              Icon(Icons.star, color: Colors.yellow, size: 20.0),
              Text('5.0 (20 Reviews)'),
            ],
          ),
          Text('20 pieces ${r"$"}90'),
          Text('Quantity: 1'),
        ])
      ])));
}

Widget ABC2(String name) {
  return (Container(
      margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      color: Colors.grey.shade200,
      height: 100,
      child: Row(children: [
        Container(
          height: 95,
          width: 95,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('assets/images/im2.jpg'),
              fit: BoxFit.cover,
            ), //DecorationImage
          ), //BoxDecoration
        ),
        Column(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Text('$name'),
          Row(
            children: [
              Icon(Icons.star, color: Colors.yellow, size: 20.0),
              Text('5.0 (20 Reviews)'),
            ],
          ),
          Text('20 pieces ${r"$"}90'),
          Text('Quantity: 1'),
        ])
      ])));
}

Widget ABC3(String name) {
  return (Container(
      margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      color: Colors.grey.shade200,
      height: 100,
      child: Row(children: [
        Container(
          height: 95,
          width: 95,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('assets/images/im3.jpg'),
              fit: BoxFit.cover,
            ), //DecorationImage
          ), //BoxDecoration
        ),
        Column(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Text('$name'),
          Row(
            children: [
              Icon(Icons.star, color: Colors.yellow, size: 20.0),
              Text('5.0 (20 Reviews)'),
            ],
          ),
          Text('20 pieces ${r"$"}90'),
          Text('Quantity: 1'),
        ])
      ])));
}

Widget ABC4(String name) {
  return (Container(
      margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      color: Colors.grey.shade200,
      height: 100,
      child: Row(children: [
        Container(
          height: 95,
          width: 95,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('assets/images/im4.jpg'),
              fit: BoxFit.cover,
            ), //DecorationImage
          ), //BoxDecoration
        ),
        Column(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Text('$name'),
          Row(
            children: [
              Icon(Icons.star, color: Colors.yellow, size: 20.0),
              Text('5.0 (20 Reviews)'),
            ],
          ),
          Text('20 pieces ${r"$"}90'),
          Text('Quantity: 1'),
        ])
      ])));
}

Widget ABC5(String name) {
  return (Container(
      margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      color: Colors.grey.shade200,
      height: 100,
      child: Row(children: [
        Container(
          height: 95,
          width: 95,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('assets/images/im5.jpg'),
              fit: BoxFit.cover,
            ), //DecorationImage
          ), //BoxDecoration
        ),
        Column(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Text('$name'),
          Row(
            children: [
              Icon(Icons.star, color: Colors.yellow, size: 20.0),
              Text('5.0 (20 Reviews)'),
            ],
          ),
          Text('20 pieces ${r"$"}90'),
          Text('Quantity: 1'),
        ])
      ])));
}

Widget ABC6(String name) {
  return (Container(
      margin: EdgeInsets.fromLTRB(0, 10, 0, 0),
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      color: Colors.grey.shade200,
      height: 100,
      child: Row(children: [
        Container(
          height: 95,
          width: 95,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('assets/images/im6.jpg'),
              fit: BoxFit.cover,
            ), //DecorationImage
          ), //BoxDecoration
        ),
        Column(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Text('$name'),
          Row(
            children: [
              Icon(Icons.star, color: Colors.yellow, size: 20.0),
              Text('5.0 (20 Reviews)'),
            ],
          ),
          Text('20 pieces ${r"$"}90'),
          Text('Quantity: 1'),
        ])
      ])));
}
