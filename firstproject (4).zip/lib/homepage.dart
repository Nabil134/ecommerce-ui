import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'slider.dart';
import 'drawer.dart';
import 'Card.dart';

class homepage extends StatefulWidget {
  @override
  _homepageState createState() => _homepageState();
}

class _homepageState extends State<homepage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, //Removing Debug Banner
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: Scaffold(
        drawer: MyDrawer(),
        backgroundColor: Color(0xffeeeeee),

        appBar: AppBar(
          title: Text("MyProducts"),
          centerTitle: true,
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.search),
              onPressed: () {},
            ), //IconButton
          ],
          backgroundColor: Colors.greenAccent[400],
        ), //AppBar
        bottomNavigationBar: BottomNavigationBar(
          selectedItemColor: Colors.green,
          unselectedItemColor: Colors.green[200],
          showUnselectedLabels: true,
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              title: Text('Home'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart),
              title: Text('Cart'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.business),
              title: Text('Categories'),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              title: Text('Profile'),
            ),
          ],
        ), //BottomNavBar
        body: ListView(
          shrinkWrap: true,
          children: [
            SizedBox(height: 20),
            CarouselClass(),
            SizedBox(height: 20),
            HorizontalProductSlider(),
            ProductBox(name: "iPhone", description: "iPhone is the top branded phone ever", price: 55000, image: "assets/images/im1.jpg"),
            ProductBox(name: "Note 20 Ultra", description: "Note 20 Ultra is the top branded phone ever", price: 35000, image: "assets/images/im2.jpg"),
            ProductBox(name: "MacBook Air", description: "MacBook Air is the top branded Laptop ever", price: 85000, image: "assets/images/im3.jpg"),
            ProductBox(name: "MacBook Pro", description: "MacBook is the top branded Stylish Laptop", price: 95000, image: "assets/images/im4.jpg"),
          ],
        ), //ListView
      ), //Scaffold
    ); //MaterailApp
  }
}

Widget HorizontalProductSlider() {
  return Column(children: [
    Padding(
      padding: EdgeInsets.fromLTRB(2, 0, 4, 0),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(
          'Our Most Liked Products',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        TextButton(
          child: Text(
            'Visit Here',
            style: TextStyle(fontSize: 20.0),
          ),
          onPressed: () {},
        ),
      ]), //Row
    ), //Padding
    SizedBox(
      height: 250,
      child: ListView.builder(
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemCount: 5,
        itemBuilder: (context, index) {
          return Stack(children: [
            Container(
              margin: EdgeInsets.all(8.0),
              height: 220,
              child: Card(
                elevation: 5.0,
                child: Container(
                  child: AspectRatio(
                    aspectRatio: 1 / 1,
                    child: Image.asset(
                      'assets/images/im2.jpg',
                      fit: BoxFit.cover,
                    ), //assetimage
                  ), //AspectRatio
                ), //Container
              ), //Card
            ), //Container
            Positioned(
              top: 25,
              left: 18,
              child: Chip(
                backgroundColor: Colors.black54,
                label: Text(
                  '50%',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ), //Chip
            ), //Positiones
          ]); //Stack
        },
      ), //lsitviewbuilder
    ), //SizedBox
  ]);
}
